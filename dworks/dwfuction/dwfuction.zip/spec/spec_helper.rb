require 'faastruby-rpc/test_helper'
require 'helpers/faastruby'
include FaaStRuby
